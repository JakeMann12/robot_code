# Jake Mann REXY environment
Basic OpenAI gym environment for Rexy the T-REX. 

Resource for [Getting Rexy to Walk with Deep Learning](https://jmann6702.wixsite.com/jake/rexy-the-t-rex). 
